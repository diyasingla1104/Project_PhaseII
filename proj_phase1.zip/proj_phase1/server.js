const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
require('./db'); // Import the MongoDB connection
const Registration = require('./models/registration'); // Your Mongoose model

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve your registration.html file
app.use(express.static(path.join(__dirname, 'public'))); // Make sure 'registration.html' is inside 'public' folder

// API route to handle form submissions
app.post('/register', async (req, res) => {
  try {
    const newUser = new Registration(req.body);
    await newUser.save();
    res.status(200).send('Registration successful');
  } catch (error) {
    console.error("Error saving to database:", error);
    res.status(500).send('Server error');
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
