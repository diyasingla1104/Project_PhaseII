const mongoose = require('mongoose');

const uri = "mongodb+srv://diya:diyasingla1104@registrations.h8dv7na.mongodb.net/corefitdb"; // connecting to 'corefitdb'

mongoose.connect(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log("✅ Connected to MongoDB Atlas!"))
.catch(err => console.error("❌ Error connecting to MongoDB Atlas:", err));
